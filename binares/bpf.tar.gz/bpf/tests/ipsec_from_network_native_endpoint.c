// SPDX-License-Identifier: (GPL-2.0-only OR BSD-2-Clause)
/* Copyright Authors of Cilium */

#define ENABLE_ENDPOINT_ROUTES 1

#define EXPECTED_STATUS_CODE_FOR_DECRYPTED TC_ACT_OK

#include "ipsec_from_network_generic.h"
