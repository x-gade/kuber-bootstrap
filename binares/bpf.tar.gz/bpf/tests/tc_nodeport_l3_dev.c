// SPDX-License-Identifier: (GPL-2.0-only OR BSD-2-Clause)
/* Copyright Authors of Cilium */

#define IS_BPF_HOST

#include "tc_nodeport_l3_dev.h"
