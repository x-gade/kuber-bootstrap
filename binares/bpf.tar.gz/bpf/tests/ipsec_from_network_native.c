// SPDX-License-Identifier: (GPL-2.0-only OR BSD-2-Clause)
/* Copyright Authors of Cilium */

#define EXPECTED_STATUS_CODE_FOR_DECRYPTED TC_ACT_REDIRECT

#include "ipsec_from_network_generic.h"
