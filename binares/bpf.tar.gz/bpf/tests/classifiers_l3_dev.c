// SPDX-License-Identifier: (GPL-2.0-only OR BSD-2-Clause)
/* Copyright Authors of Cilium */

#define IS_BPF_WIREGUARD 1

#include "classifiers_common.h"
