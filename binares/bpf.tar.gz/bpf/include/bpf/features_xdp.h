
/* SPDX-License-Identifier: (GPL-2.0-only OR BSD-2-Clause) */
/* Copyright Authors of Cilium */

/* THIS FILE WAS GENERATED DURING AGENT STARTUP. */

#pragma once
#include "features.h"
